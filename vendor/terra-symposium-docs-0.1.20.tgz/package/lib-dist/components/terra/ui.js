import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Component } from 'react';
export class ErrorBoundary extends Component {
    state = { error: null };
    static getDerivedStateFromError(error) {
        return { error };
    }
    componentDidCatch(_error, _info) { }
    render() {
        return this.state.error
            ? (this.props.fallback?.(this.state.error) ?? (_jsx("div", { role: "alert", children: this.state.error.message })))
            : this.props.children;
    }
}
export function Empty({ title = 'Nothing to show', description = '', }) {
    return (_jsxs("div", { className: "flex min-h-24 flex-col items-center justify-center gap-2 p-6 text-center text-primary-11", children: [_jsx("strong", { className: "text-primary-12", children: title }), description && _jsx("span", { children: description })] }));
}
export const IMG_RESPONSIVE = 'max-w-full object-contain';
export default function User({ user, }) {
    return _jsx("span", { className: "text-sm text-primary-11", children: user?.name ?? user?.email ?? '' });
}
//# sourceMappingURL=ui.js.map