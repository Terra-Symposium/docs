/**
 * astro/src/components/flow/Nodes.tsx
 */
import React from 'react';
import type { Node as XyNode, NodeProps } from '@xyflow/react';
import type { NodeData } from '../../../lib/terra/runtime/types.js';
import type { GroupNodeData, NodesProps } from '../../../lib/terra/runtime/types.js';
/**
 * Renders the container node used to group related flowchart nodes.
 *
 * @param props - Flow node props.
 * @param data - Group node data and resize hooks.
 * @param selected - Boolean flag controlling group node's selected behaviour.
 *
 * @return Resizable group frame, title bar, and group handles.
 */
export declare function GroupNode({ data, selected }: NodeProps<XyNode<GroupNodeData>>): React.JSX.Element;
/**
 * Renders a sticky-note style node in the flowchart.
 *
 * @param props - Flow node props.
 * @param id - Unique clipping mask identifier.
 * @param data - Sticky note text and resize hooks.
 * @param selected - Boolean flag controlling note node's selected behaviour.
 *
 * @return Sticky note styled container.
 */
export declare function NoteNode({ id, data, selected, }: NodeProps<XyNode<GroupNodeData>>): React.JSX.Element;
export declare const NODE_TYPES: {
    erd: ({ data, selected }: NodeProps<XyNode<NodeData>>) => React.JSX.Element;
    process: (props: NodeProps<XyNode<NodeData>>) => React.JSX.Element;
    terminator: (props: NodeProps<XyNode<NodeData>>) => React.JSX.Element;
    origin: (props: NodeProps<XyNode<NodeData>>) => React.JSX.Element;
    terminal: (props: NodeProps<XyNode<NodeData>>) => React.JSX.Element;
    decision: (props: NodeProps<XyNode<NodeData>>) => React.JSX.Element;
    data: (props: NodeProps<XyNode<NodeData>>) => React.JSX.Element;
    note: typeof NoteNode;
    group: typeof GroupNode;
};
/**
 * Renders the flow editor wrapper used by docs diagrams.
 *
 * @param props - Initial nodes and edges, layout configuration, interactions, change callbacks, and display settings for the problem graph.
 * @param className - Extra classes applied to the outer flow wrapper.
 * @param onCommit - Callback that receives the fully normalised flow after each change.
 * @param nodes - Graph nodes rendered and updated by nodes.
 * @param edges - Graph connections rendered and updated by nodes.
 * @param nodeSep - Horizontal gap between graph nodes in nodes.
 * @param rankSep - Vertical gap between graph ranks in nodes.
 * @param height - Viewport height reserved for nodes's graph surface.
 * @param onAddContent - Callback invoked for add content.
 * @param onNodeClick - Callback invoked when a user selects a node in nodes.
 * @param nodeTypes - Node renderer map that draws graph nodes in nodes.
 * @param nodeLabels - Node label map shown alongside nodes's graph nodes.
 * @param lockedTypes - Node types that nodes must keep read-only.
 * @param allowedTypes - Node types that nodes permits users to create.
 * @param disabled - Disabled state controlling whether nodes accepts interaction.
 * @param clipboardKey - Clipboard key that enables graph copy and paste in nodes.
 * @param arcControls - Arc controls input supplied to nodes's operation.
 * @param edgeTypes - Edge renderer map that draws graph connections in nodes.
 * @param readyWhenEmpty - Readiness rule that lets nodes finish with no graph nodes.
 * @param onReady - Callback invoked when nodes finishes initialising its graph surface.
 * @param style - Inline style values merged into nodes.
 * @param rest - Rest input supplied to nodes's operation.
 * @param direction - Layout direction that arranges nodes's graph.
 * @param interactive - Interaction flag that controls whether nodes accepts graph input.
 * @param editable - Editability flag controlling whether nodes accepts changes.
 * @param proximityConnect - Connection rule that lets nearby graph nodes link automatically in nodes.
 * @param showBg - Visibility flag for nodes's graph background.
 * @param showCtrls - Visibility flag for nodes's graph controls.
 *
 * @return Docs flow editor wrapper with derived height, toolbar controls, and drag state.
 *
 * @remarks
 * This is the public entrypoint; the rest of the file exists to keep the canvas state manageable.
 */
export default function Nodes({ nodes: initialNodes, edges: initialEdges, className, direction: dir, nodeSep, rankSep, proximityConnect, interactive, height, onCommit, onAddContent, onNodeClick, nodeTypes: customNodeTypes, nodeLabels, lockedTypes, allowedTypes, editable, disabled, clipboardKey, showBg, showCtrls, arcControls, edgeTypes, readyWhenEmpty, onReady, style, ...rest }: NodesProps): React.JSX.Element;
//# sourceMappingURL=Nodes.d.ts.map