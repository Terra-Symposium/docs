import { jsxs as _jsxs } from "react/jsx-runtime";
// @ts-nocheck -- source-preserving extraction; public host contracts are typed in src/host.ts.
/**
 * astro/src/components/editor/docs/_math_inline.tsx
 * Read-only Docs math inline renderer for the shared Terra content editor.
 */
/*//////////////////////////////////////////////////
IMPORTS
//////////////////////////////////////////////////*/
// API
import { renderMath } from './_Math.js';
/*//////////////////////////////////////////////////
COMPONENTS
//////////////////////////////////////////////////*/
/**
 * Renders a read-only Docs formula as an inline Portable Text object.
 *
 * @param props - Portable Text inline-object attributes, children, and node.
 *
 * @return Inline rendered formula.
 */
export default function MathInline({ attributes: attrs, children, node, }) {
    return (_jsxs("span", { ...attrs, className: "mx-1 inline align-baseline", contentEditable: false, "data-terra-inline": "math", suppressContentEditableWarning: true, children: [renderMath({
                code: node.code || '',
                inline: true,
                className: 'align-baseline',
            }), children] }));
}
Object.assign(MathInline, { displayName: 'DocsMathInline' });
//# sourceMappingURL=_math_inline.js.map