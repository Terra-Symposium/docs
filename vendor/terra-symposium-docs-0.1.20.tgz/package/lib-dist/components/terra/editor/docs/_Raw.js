import { jsx as _jsx } from "react/jsx-runtime";
// @ts-nocheck -- source-preserving extraction; public host contracts are typed in src/host.ts.
/**
 * astro/src/components/editor/docs/_Raw.tsx
 */
/*//////////////////////////////////////////////////
IMPORTS
//////////////////////////////////////////////////*/
// COMPONENTS
import { CodeBlock } from './_CodeBlock.js';
import { ErrorBoundary } from '../../ui.js';
/*//////////////////////////////////////////////////
HELPERS
//////////////////////////////////////////////////*/
/**
 * Renders the raw component.
 *
 * @param props - Raw block props containing the authored markup.
 *
 * @return Rendered raw documentation content.
 */
export function Raw({ block, }) {
    return (_jsx(ErrorBoundary, { name: "Raw", children: _jsx(CodeBlock, { docsSource: true, code: block.markdown ?? '', language: "mdx", tone: "view" }) }));
}
Object.assign(Raw, { displayName: 'DocsRawMarkup' });
//# sourceMappingURL=_Raw.js.map