/**
 * astro/src/pages/docs/_export-dialog.tsx
 */
import type { DocsExportOpts as ExportOptions, ExportTgt } from '../../../../lib/terra/runtime/types.js';
import type { ReactElement } from 'react';
/**
 * Renders the export dialog component.
 *
 * @param props - Export target, document data, and dialog state callbacks.
 *
 * @return Dialog for exporting documentation content.
 */
export declare function ExportDialog({ target: tgt, setTarget: setTgt, disabled, onExport, }: {
    target: ExportTgt;
    setTarget: (val: ExportTgt) => void;
    disabled?: boolean;
    onExport: (tgt: Exclude<ExportTgt, null>, opts: ExportOptions, progress: (val: number) => void) => Promise<void>;
}): ReactElement | null;
//# sourceMappingURL=_export-dialog.d.ts.map