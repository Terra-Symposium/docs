export declare function useRenderTripwire(componentName: string, trackedVars: Record<string, unknown>): void;
//# sourceMappingURL=use-render-tripwire.d.ts.map