/** Manages attachments for a Docs page, group, or section. */
import React from 'react';
import type { AttchTgt, Tree as TreeType } from '../../../../lib/terra/runtime/types.js';
export declare function ManageAttachmentsDialog({ tgt, setTgt, disabled, tree, }: {
    tgt: AttchTgt | null;
    setTgt: React.Dispatch<React.SetStateAction<AttchTgt | null>>;
    disabled: boolean;
    tree: TreeType[];
}): React.JSX.Element | null;
//# sourceMappingURL=_manage-attachments-dialog.d.ts.map