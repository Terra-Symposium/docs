/**
 * astro/src/pages/docs/_main.tsx
 * Docs scaffold entrypoint, shell, transition ctx, and compiled view/edit surfaces.
 * Folder boundary: page composition and shared Docs state; block rendering, editing, chrome, and navigation remain separate.
 */
import type { ReactNode } from 'react';
import type { DocBody, DocVer } from '../../../../lib/terra/runtime/types.js';
import type { DocsPermissionLevel as Permission, Mode, Tree as TreeType } from '../../../../lib/terra/runtime/types.js';
import type { User } from '../../../../lib/terra/runtime/types.js';
/**
 * Renders the scaffold component.
 *
 * @param props - Tree, route, user, document content, edit permission, metadata, and display mode for the Docs page shell.
 * @param tree - Tree input supplied to scaffold's operation.
 * @param pathname - Pathname input supplied to scaffold's operation.
 * @param permission - Permission input supplied to scaffold's operation.
 * @param userData - user record supplied to scaffold.
 * @param description - Supporting text shown in scaffold.
 * @param contributors - Contributors input supplied to scaffold's operation.
 * @param updatedAt - Updated at input supplied to scaffold's operation.
 * @param full - Full input supplied to scaffold's operation.
 * @param standalone - Standalone input supplied to scaffold's operation.
 * @param path - Source or route path resolved for scaffold.
 * @param compiledMDX - Compiled mdx input supplied to scaffold's operation.
 * @param title - Heading text shown in scaffold.
 * @param source - Source node identifier for the connection drawn by scaffold.
 * @param content - Content input supplied to scaffold's operation.
 * @param mode - Mode input supplied to scaffold's operation.
 *
 * @return The Docs scaffold with its navigation tree, content surface, and page controls.
 */
export default function Scaffold({ tree, pathname: initPathname, permission, userData, description: initDesc, contributors: initContributors, updatedAt: initUpdatedAt, full, standalone, path: initPath, compiledMDX: initMdx, title: initTitle, source: initSrc, content: initContent, mode: initialMode, viewContent, }: {
    tree: TreeType[];
    pathname: string;
    permission: Permission;
    userData: User | null;
    description?: string;
    full?: boolean;
    standalone?: boolean;
    path?: string;
    compiledMDX?: string;
    title: string;
    source?: string;
    content?: string | DocVer[] | DocBody;
    contributors?: string[];
    updatedAt?: string;
    mode?: Mode;
    viewContent?: ReactNode;
}): JSX.Element;
//# sourceMappingURL=_main.d.ts.map