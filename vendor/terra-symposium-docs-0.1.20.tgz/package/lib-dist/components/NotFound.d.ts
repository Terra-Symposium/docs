import type { JSX } from 'react';
export type DocsNotFoundProps = {
    appName?: string;
    homeHref?: string;
    description?: string;
};
export declare function DocsNotFound({ appName, homeHref, description, }: DocsNotFoundProps): JSX.Element;
//# sourceMappingURL=NotFound.d.ts.map