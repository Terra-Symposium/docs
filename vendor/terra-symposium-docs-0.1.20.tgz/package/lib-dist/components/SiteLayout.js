import { jsx as _jsx } from "react/jsx-runtime";
import { DocsStaticWorkspace } from './StaticWorkspace.js';
/**
 * Compatibility adapter for static React sites.
 *
 * All navigation, page chrome, modes, and document rendering are delegated to
 * the same TerraDocsWorkspace used by the local and remote host adapters.
 */
export function DocsSiteLayout({ title, homeHref = '/', description, pageTitle, nodes, currentPath, hue = 145, children, sections, attachments = [], rootPath, markdown, content, }) {
    return (_jsx(DocsStaticWorkspace, { title: title, homeHref: homeHref, ...(description ? { description } : {}), ...(pageTitle ? { pageTitle } : {}), hue: hue, nodes: nodes, ...(sections ? { sections } : {}), currentPath: currentPath, ...(rootPath ? { rootPath } : {}), ...(markdown !== undefined ? { markdown } : {}), ...(content !== undefined ? { content } : {}), attachments: attachments, ...(children !== undefined ? { renderContent: children } : {}) }));
}
//# sourceMappingURL=SiteLayout.js.map