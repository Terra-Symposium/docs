import type { DocsBlockOptions } from '../components/blocks.js';
export declare function renderMarkdown(markdown: string, options?: DocsBlockOptions): string;
//# sourceMappingURL=markdown.d.ts.map