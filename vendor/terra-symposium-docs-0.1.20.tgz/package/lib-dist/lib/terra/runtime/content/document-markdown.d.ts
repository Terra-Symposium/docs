import type { DocBody } from '../types.js';
/**
 * Stringifies the Doc Content Body for the docs.
 *
 * @param body - Structured docs content to serialize.
 *
 * @returns Markdown or MDX source for the provided body, or an empty string for empty input.
 *
 * @remarks
 * Empty bodies return an empty string so callers can short-circuit easily.
 */
export declare const stringifyDocBody: (body: DocBody | null | undefined) => string;
/**
 * Stringifies the Editor Content Body for the docs.
 *
 * @param body - Structured docs content to serialize.
 *
 * @returns MDX source that MDXEditor can reopen without delimiter-rewrite drift.
 *
 * @remarks
 * Accordions, tabs, and tables are emitted as explicit JSX so nested HTML never relies on regex block rewriting.
 */
export declare const stringifyEditorContentBody: (body: DocBody | null | undefined) => string;
/**
 * Handles stringify problem editor content body.
 *
 * @param body - Problem editor body to serialize into Markdown source.
 */
export declare const stringifyProblemEditorContentBody: (body: DocBody | null | undefined) => string;
/**
 * Serializes the current leaf content payload without inspecting ver history.
 *
 * @param content - Direct `leaf.content` value or a compatibility wrapper around it.
 *
 * @returns Markdown or MDX for the active document body only.
 *
 * @remarks
 * This is the preferred live-doc read path now that leaf content is stored directly.
 */
export declare const currDocMd: (content: unknown) => string;
//# sourceMappingURL=document-markdown.d.ts.map