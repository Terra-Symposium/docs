/**
 * Rewrites the supported docs block markers into their JSX wrapper forms.
 *
 * @param md - Markdown or MDX source to normalize.
 *
 * @return Source where supported block markers have been rewritten to their JSX wrappers.
 *
 * @remarks
 * Only the supported block syntaxes are rewritten; everything else is preserved.
 */
export declare function toBlockJsx(md: string): string;
/**
 * Restores the custom docs JSX wrappers back to the markdown block syntax they came from.
 *
 * @param jsx - Canonical JSX source to restore.
 *
 * @return Markdown where supported docs JSX wrappers have been converted back to block syntax.
 *
 * @remarks
 * This is the inverse of `toBlockJsx` for the supported docs block shapes.
 */
export declare function fromBlockJsx(jsx: string): string;
//# sourceMappingURL=block-jsx.d.ts.map