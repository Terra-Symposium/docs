import type { DocsCustomBlock } from '../host.js';
/** Mutated in place by a host before the workspace renders. */
export declare const components: DocsCustomBlock[];
export declare function setDocsCustomComponents(next: DocsCustomBlock[]): void;
//# sourceMappingURL=custom-components.d.ts.map