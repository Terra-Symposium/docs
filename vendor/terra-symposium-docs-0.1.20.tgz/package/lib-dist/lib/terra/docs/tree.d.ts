import { parseRoute } from '../runtime/shared.js';
import type { Tree as TreeType } from '../runtime/types.js';
export declare const parseDocsRoute: (pathname: string) => ReturnType<typeof parseRoute>;
export declare const sanitizeName: (name: string) => string;
/**
 * Handles is index file.
 *
 * @param path - Docs path to normalize into a route-safe identifier.
 */
export declare const isIndexFile: (path: string) => boolean;
export declare const getStableKey: (node: TreeType) => string;
export declare function extractAllNodeIds(nodes: TreeType[]): string[];
export declare function getSiblings(nodes: TreeType[], targetPath: string): TreeType[];
export declare const keepDeepPath: (curr: string, n: string) => string;
//# sourceMappingURL=tree.d.ts.map