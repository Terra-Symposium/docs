export declare function uploadAssetChunked(file: File, dPath: string, opts?: {
    resize?: boolean;
    grayscale?: boolean;
    previewAssetPath?: string;
    onProgress?: (data: {
        bytes: number;
        currentChunk: number;
        totalChunks: number;
        message?: string;
    }) => void;
}): Promise<{
    path?: string;
    src?: string;
    compressedSize?: number;
    name?: string;
}>;
/**
 * Handles download.
 *
 * @param filename - Filename input supplied to download's operation.
 * @param content - Content input supplied to download's operation.
 * @param type - Type input supplied to download's operation.
 */
export declare function download(filename: string, content: string | ArrayBuffer | Blob, type?: string): void;
//# sourceMappingURL=assets.d.ts.map