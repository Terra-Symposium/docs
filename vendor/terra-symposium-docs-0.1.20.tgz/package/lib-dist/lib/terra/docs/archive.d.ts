import type { DocsExportOpts as ExportOptions } from '../runtime/types.js';
export declare function archiveDocs(v: string[], r: string, f: string, o: ExportOptions, d?: (percent: number) => void, n?: string[]): Promise<void>;
//# sourceMappingURL=archive.d.ts.map