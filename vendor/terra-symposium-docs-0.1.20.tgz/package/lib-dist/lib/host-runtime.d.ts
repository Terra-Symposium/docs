import type { DocsCustomBlock, DocsHostAdapter } from './host.js';
export declare function getDocsHostAdapter(): DocsHostAdapter | undefined;
/** Install host-owned storage and capability checks before mounting the Docs surface. */
export declare function configureDocsHost(host: DocsHostAdapter, customBlocks?: DocsCustomBlock[]): void;
//# sourceMappingURL=host-runtime.d.ts.map